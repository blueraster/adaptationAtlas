Technical And Source Notes
Population, Health and Human Well-being � Public Health: Malaria, reported cases
Technical Notes

Adapted from: World Health Organization (WHO) and the United Nations Children's Fund (UNICEF). 2005. World Malaria Report 2008. Geneva: WHO. Available online at: http://www.who.int/malaria/wmr2008/.

Definition:
Malaria, reported cases refers to the total number of malaria cases reported to the World Health Organization (WHO) by countries in which malaria is endemic. According to the WHO endemic is a "term applied to malaria when there is a constant measurable incidence both of cases and of natural transmission in an area over a succession of years." Countries that have only imported cases or introduced cases resulting from imported cases are not included in this dataset. Reported cases include those confirmed by laboratory diagnosis, but also include cases based solely on a clinical diagnosis (without laboratory testing), particularly estimates for countries in Sub-Saharan Africa.

Malaria is a single-celled parasite that is transmitted to humans by the bite of an infected mosquito (disease vector). Malaria is one of the world's prevalent health crises�an estimated 3.2 billion people are still at risk and malaria kills more than one million people annually.

Years Covered and Frequency of Update:
This dataset contains estimates from 1990 to 2007, although some annual data are missing for some countries (typically those in Sub-Saharan Africa).

WHO's Global Health Atlas database (available online) is updated approximately annually.

Methodology:
WHO's Global Malaria Programme has been systematically compiling information on malaria since 2002. Data on malaria are collected from several sources:

National Health Information Systems (HIS) are the primary source of national data for malaria cases and deaths seen in health facilities. WHO regional offices request this information annually from country officials and national malaria control programs, though not all facilities and districts report. HIS are well-developed in several countries where malaria is endemic in Asia, the Americas, and Europe, but relatively few countries in Africa.

Multiple Indicator Cluster Surveys (MICS) were conducted in 67 countries between 1999 and 2001. MICS are nationally representative, with an average sample size of approximately 6000 households. The survey questionnaires include optional modules with questions regarding the prevalence of fever, as well as the possession and use of treatments (antimalarial drugs) and preventative measures (insecticide-treated nets) for malaria.

Demographic and Health Surveys (DHS) are nationally representative household surveys consisting of interviews with 4000-12000 women between 15 and 49 years of age. DHS focus on reproductive and child health, and have included specific questions on malaria prevention and treatment since 1998. Since 2001, these questions have been grouped in a standard malaria module, to be included in surveys conducted in all countries where malaria is endemic. For additional information, including survey results and questionnaires, please refer to the DHS website.

Some incidental national surveys conducted by health ministries were also included. In some instances, where national surveys were deemed inadequate, high-quality sub-national surveys were considered.

For a complete description of indicators of malaria available through the WHO, their respective sources, and reporting frequency, please refer to the WHO and UNICEF World Malaria Report 2008 and the WHO Roll Back Malaria (2000) publication Framework for Monitoring Progress and Evaluating Outcomes and Impact.

Data Reliability:
The data refer to reported malaria cases only. These data may reflect only a fraction of the true number of malaria cases in a country because of incomplete reporting systems or incomplete coverage by health services, or both. Also, many malaria patients may seek treatment outside of the formal health sector. Comparisons between countries should be made with caution as case detections and reporting systems vary widely. However, if data reporting is reasonably consistent and complete over this time period, these data (malaria cases reported) serve as a good gauge of trends in national malaria burdens.
 
Source

World Health Organization (WHO). 2009. Global Health Atlas. Geneva: WHO. Available online at: http://www.who.int/globalatlas/. 