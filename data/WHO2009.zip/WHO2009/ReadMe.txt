Thank you for your interest in the Global Adaptation Atlas, www.adaptationatlas.org.

You have downloaded a zip file which contains the original study data, published spatial data and a metadata file for an individual study from the Global Adaptation Atlas.  Specifically, the zip file contains:


1) An .html metadata document describing the data

2) The original source data for the entire study is in the folder called, Original_Data.

3) The published spatial data for the entire study is in the folder called, Layer_Package.


The spatial data is provided to you in an ESRI Layer Package format*.  

You will need access to ESRI ArcGIS Desktop software version 9.3.1 or higher to view the map layers in the Layer Package.

     http://www.esri.com/software/arcgis/arcview

For help on using Layer Packages in ArcGIS Desktop:

     http://webhelp.esri.com/arcgisdesktop/9.3/index.cfm?id=214&pid=212&topicname=Adding_a_layer_package_to_your_map

If you do not have access to ESRI ArcGIS Desktop v9.3.1 or higher, you may view the layers in the Layer Packages by downloading and installing ArcGIS Explorer, a free GIS viewer that gives you an easy way to explore, visualize, and share GIS information. 

     http://www.esri.com/software/arcgis/explorer

For help on using Layer Packages in ArcGIS Explorer:

     http://webhelp.esri.com/arcgisexplorer/900/en/index.html#add_arcgis_layers.htm

For a description of the study and procedures used to generate layers, please refer to the metadata document, the .html file included in this folder.

*NOTE � The extracted Layer Package will create a .lyr file and a file geodatabase containing the feature classes for each layer published for the study.  The feature classes may contain null values representing no data.  If you export the feature class to a shapefile it may result in coverting null values to zeros and thus corrupt the original data values.  To learn more about this issue, please reference the following ESRI technical article: 

     http://support.esri.com/index.cfm?fa=knowledgebase.techarticles.articleShow&d=20177.

Please address all questions regarding the data to data@adaptationatlas.org.

Thank you.




